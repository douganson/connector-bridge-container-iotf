#!/bin/sh

echo "Stopping Connector Bridge..."
./killConnectorBridge.sh
